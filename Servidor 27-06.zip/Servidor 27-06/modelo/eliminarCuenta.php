<?php
include('conex.php');

$cod_rubro = $_POST['cod_rubro'];
$cod_bloque = $_POST['cod_bloque'];
$cod_grupo = $_POST['cod_grupo'];
$cod_cuenta = $_POST['cod_cuenta'];




?>