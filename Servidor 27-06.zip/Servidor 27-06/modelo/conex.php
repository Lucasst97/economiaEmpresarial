<?php

$conex = mysqli_connect("localhost", "id19095293_usereconomia", "05}<AAsjPQyLfQMV", "id19095293_economiaempresarial");

if($conex){
    
}
?>
