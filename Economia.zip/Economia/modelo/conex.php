<?php

$conex = mysqli_connect("localhost", "root", "", "economia_empresarial");


?>